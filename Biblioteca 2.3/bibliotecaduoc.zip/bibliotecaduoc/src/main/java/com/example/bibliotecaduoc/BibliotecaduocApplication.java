package com.example.bibliotecaduoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaduocApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaduocApplication.class, args);
	}

}
