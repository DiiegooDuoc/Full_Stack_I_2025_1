package com.example.bibliotecaduoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaduocApplicationTests {

	@Test
	void contextLoads() {
	}

}
